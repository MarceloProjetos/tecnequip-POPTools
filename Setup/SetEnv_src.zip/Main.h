#ifndef _HDR_TestConsole_H
#define _HDR_TestConsole_H

	// Skeleton code for a simple console application

	// History
		// Version 1.04 (Support for user variables)
		// Version 1.03 (Fix - Buffer size problem)
		//		- Bugfix for problem found by attiasr
		//		- http://www.codeproject.com/tools/SetEnv.asp#xx1454198xx
		// Version 1.02 (Added Strsafe functionality)
		// Version 1.01 (Added 'xfc' namespace)
		// Version 1.00 (Initial Release)

	// License - Free for any purpose, just do not remove the copyright
	// Copyright (C) 1997-2006 - Jonathan Wilkes

#ifndef _WINDOWS_
	#include <windows.h>
#endif

#include <stdio.h>
#include <iostream>
#include <tchar.h>
#include <strsafe.h> // Must be last include

namespace xfc
{
const int ERR_SUCCESS = 0;
const int ERR_ERROR = 1;
const int ERR_ACCESS_DENIED = 5;

const int i98_BUFFERLEN = 30;

	// Our output routine for displaying messages to the console window
void Output(LPCTSTR pBuff);

	// Outputs a message to stderr
void OutputErr(LPCTSTR pBuff);

	// Display a system error message to the console window
void DisplaySysError(LPCTSTR pszBuff, DWORD dwErr);
}

#endif // _HDR_TestConsole_H
